console.log("corriendo...")

import router from './routes';

window.addEventListener('load', router);
window.addEventListener('hashchange', router);